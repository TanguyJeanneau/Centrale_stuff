// The Class Pixel is in the package image : 
package image;
import image.color.GrayColor;
import java.lang.Math;


/**
 * class Pixel to model the pixels defining an image. 
 * 
 * @author adrien and Tanguy
 */
public class Pixel {
	
	private GrayColor graycolor;
	
	/**
	 * Gets the color of a pixel
	 * @return the color of a pixel
	 */
	public GrayColor getColor(){
		return this.graycolor;
	}
	/**
	 * Sets the color of a pixel : 
	 * @param g, level attribute from the class Graycolor
	 */
	
	public void setColor(GrayColor g) {
		this.graycolor = g;
	}
	
	/**
	 * Constructor of the class pixel
	 * @param level : int, representing the level of gray
	 */
	public Pixel(int level){
		GrayColor graycolor = new GrayColor(level);
		this.graycolor = graycolor;
	}
	
	/**
	 * Method equals of the class Pixel :
	 */
	public boolean equals(Object o) {
			
			if (o instanceof Pixel) {
				// conversion de type
				Pixel that = (Pixel)o;
				return this.graycolor.equals(that.getColor());
				} else {
				return false;
				}
		}
	
	/**
	 * Method to get the difference of the level of gray between two pixel
	 * @param that : Pixel to which it must be compared 
	 * @return int, difference of level of gray between the two pixels. 
	 */
	public int colorDifference(Pixel that) {
		return Math.abs(that.getColor().getLevel()- this.graycolor.getLevel());
	}
	
	/*TEST : 
	public static void main(String[] args){
		System.out.println("�a fonctionne");
		Pixel pixel1 = new Pixel(3);
		Pixel pixel2 = new Pixel(40);
		int d = pixel1.colorDifference(pixel2);
		System.out.println(d);
	}
	 */

	
	
}
